package org.nightschool.demo;

public class Calculator {
    //example
    public int plus(int num1, int num2) {
        return num1 + num2;
    }

    //a half done work
    public int minus(int num1, int num2) {
        return num1 + num2;
    }

    //Todo: implement the multiply method
//    public int multiply(int num1, int num2) {
//
//    }

}
