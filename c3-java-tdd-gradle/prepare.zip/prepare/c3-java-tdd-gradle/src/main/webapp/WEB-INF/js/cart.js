function addToCartButton(name) {
    return $("<button>")
        .html("add to cart")
        .click(function () {
            addToCart(name);
        });
}

function addToCart(name) {

}

function goToCart() {

}
