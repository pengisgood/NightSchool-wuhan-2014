var selectedItems = [];

function addToCartButton(name) {
    return $("<button>")
        .html("buy")
        .click(function () {
            addToCart(name);
        });
}

function addToCart(name) {
    var item = _.find(disks, function (disk) {
        return disk.name === name;
    });

    selectedItems.push(item);
}

function goToCart() {
    console.log(selectedItems);
}
