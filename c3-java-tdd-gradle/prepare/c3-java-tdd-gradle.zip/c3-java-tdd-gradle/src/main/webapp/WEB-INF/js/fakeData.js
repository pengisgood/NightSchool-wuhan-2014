var disks = [{
  name: "小清新光盘",
  img: "../images/disk/fancy-disk.jpg",
  desc: "小清新、小文艺 35元/10张"
}, {
  name: "婚庆光盘",
  img: "../images/disk/marriage-disk.jpg",
  desc: "记录你的美好瞬间 50元/10张"
}, {
  name: "1TB大容量光盘",
  img: "../images/disk/1TB-disk.jpg",
  desc: "解放你的硬盘  100元/10张"
}];
